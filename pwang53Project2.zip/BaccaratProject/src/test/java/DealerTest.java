import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DealerTest {
	ArrayList<Card> p;
	ArrayList<Card> b;
	BaccaratDealer dealer;
	BaccaratGameLogic gameLogic;
	
	//initial the members
	@BeforeEach
	void initial() {
		p = new ArrayList<Card>();
		b = new ArrayList<Card>();
		dealer = new BaccaratDealer();
		gameLogic = new BaccaratGameLogic();
		dealer.generateDeck();
	}
	
	//test card constructor
	@Test
	void t_Class_Card() {
		Card card = new Card("Spade", 2);
		assertEquals(2,card.value);
	}
	
	//test generate 52 cards in the deck
	@Test
	void t1_generateDeck() {
		assertEquals(52, dealer.deckSize());
	}
	
	//test there will not have value 14 card in the deck
	@Test
	void t2_generateDeck() {
		for(int i = 0; i < dealer.deckSize(); i++) {
			assertFalse(dealer.deck.get(i).value == 14);
		}
	}
	
	//test dealHand draw 2 cards
	@Test
	void t1_dealHand() {
		ArrayList<Card> temp = dealer.dealHand();
		assertEquals(2, temp.size());
	}
	
	//test if card in the deck is 0, continue to deal will have no card
	@Test
	void t2_dealHand() {
		//to draw all cards in the deck
		for(int i = 0; i < 26; i ++) {
			dealer.dealHand();
		}
		ArrayList<Card> temp = dealer.dealHand();
		assertEquals(null, temp);
	}
	
	//test draw a card, the deck will have 51 cards
	@Test
	void t1_drawOne() {
		dealer.drawOne();
		assertEquals(51, dealer.deckSize());
	}
	
	//test draw all cards, will return null to draw
	@Test
	void t2_drawOne() {
		//to draw all cards in the deck
		for(int i = 0; i < 52; i ++) {
			dealer.drawOne();
		}
		Card temp = dealer.drawOne();
		assertEquals(null, temp);
	}
	
	//test after shuffling, the card number should still be 52
	@Test
	void t1_shuffleDeck() {
		dealer.shuffleDeck();
		assertEquals(52, dealer.deckSize());
	}
	
	//test After shuffling, the dealer still under class
	@Test
	void t2_shuffleDeck() {
		dealer.shuffleDeck();
		assertEquals("BaccaratDealer", dealer.getClass().getName());
	}
	
	//test size is correct
	@Test
	void t1_deckSize() {
		assertEquals(52, dealer.deckSize());
	}
	
	//test the function return size is integer not string
	@Test
	void t2_deckSize() {
		assertNotEquals("a", dealer.deckSize());
	}
	
	//test the BaccaratDealer constructor
	@Test
	void t_Class_BaccaratDealer() {
		assertNotEquals(null, dealer.deck);
	}
	
	//test hand total 2 + 4 = 6 points
	@Test
	void t1_handTotal(){
		p.add(new Card("Heart", 2));
		p.add(new Card("Heart", 4));
		assertEquals(6, gameLogic.handTotal(p));
	}
	
	//test whether 10, J, Q, K account as 0 point
	@Test
	void t2_handTotal(){
		p.add(new Card("Heart", 10));
		p.add(new Card("Heart", 11));
		assertEquals(0, gameLogic.handTotal(p));
	}
	
	//test the condition of Draw: player 0, banker 0
	@Test
	void t1_whoWon(){
		p.add(new Card("Heart", 10));
		p.add(new Card("Heart", 11));
		b.add(new Card("Heart", 12));
		b.add(new Card("Heart", 11));
		assertEquals("Draw", gameLogic.whoWon(p, b));
	}
	
	//test the condition of banker won: player 5, banker 2
	@Test
	void t2_whoWon(){
		p.add(new Card("Heart", 10));
		p.add(new Card("Heart", 5));
		b.add(new Card("Heart", 1));
		b.add(new Card("Spade", 1));
		assertEquals("Player", gameLogic.whoWon(p, b));
	}
	
	//test if banker point is 2 (<3), should draw
	@Test
	void t1_evaluateBankerDraw(){
		b.add(new Card("Heart", 1));
		b.add(new Card("Spade", 1));
		Card playerCard = new Card("Spade" , 10);
		assertEquals(true, gameLogic.evaluateBankerDraw(b, playerCard));
	}
	
	//test if banker point is 3  and player point is 5, should draw
	@Test
	void t2_evaluateBankerDraw(){
		b.add(new Card("Heart", 1));
		b.add(new Card("Spade", 2));
		Card playerCard = new Card("Spade" , 5);
		assertEquals(true, gameLogic.evaluateBankerDraw(b, playerCard));
	}
	
	//test if player point is smaller than 6, should draw
	@Test
	void t1_evaluatePlayerDraw() {
		p.add(new Card("Heart", 10));
		p.add(new Card("Heart", 5));
		assertEquals(true, gameLogic.evaluatePlayerDraw(p));
	}
	
	//test if player point is greater than 6, should draw
	@Test
	void t2_evaluatePlayerDraw() {
		p.add(new Card("Heart", 10));
		p.add(new Card("Heart", 8));
		assertEquals(false, gameLogic.evaluatePlayerDraw(p));
	}
	
	//test game logic constructor
	@Test
	void t_Class_BaccaratGameLogic() {
		assertNotEquals(null, gameLogic);
	}
	
	//test winning case, bet banker win 95%
	@Test
	void t1_evaluateWinnings() {
		BaccaratGame game = new BaccaratGame();
		game.whowon = "Banker";
		game.betWho = "Banker";
		game.currentBet = 50;
		game.evaluateWinnings();
		assertEquals(47.5, game.totalWinnings);
	}
	
	//test losing case
	@Test
	void t2_evaluateWinnings() {
		BaccaratGame game = new BaccaratGame();
		game.whowon = "Banker";
		game.betWho = "Draw";
		game.currentBet = 10.5;
		game.evaluateWinnings();
		assertEquals(-10.5, game.totalWinnings);
	}
	
	//test BaccarateGame constructor
	@Test
	void t_Class_BaccarateGame() {
		BaccaratGame game = new BaccaratGame();
		assertEquals("BaccaratGameLogic", game.gameLogic.getClass().getName());
	}
}
