import java.util.ArrayList;
import java.util.Random;

class BaccaratDealer{
	//Need have a deck of card
	ArrayList<Card> deck = new ArrayList<Card>();
	private final int MAX_DECK_SIZE = 52;
	//int currentCard = 0;
	
	//To generate a deck of card (52 cards) 
	public void generateDeck() {
		
		//Method 1 to generate;
		int[] myValue = {1, 2 ,3 , 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
		String[] mySuites = {"Heart", "Spade", "Club", "Diamond"};
		
		for (int i= 0; i < MAX_DECK_SIZE; i++) {
			Card theCard = new Card(null, 0);
			theCard.value = myValue[i % 13];
			theCard.suite = mySuites[i / 13];
			deck.add(theCard);
		}
		
		//Method 2 to generate
		/*for (int i= 0; i < 13; i++) {
			Card theCard1 = new Card(null, 0);
			Card theCard2 = new Card(null, 0);
			Card theCard3 = new Card(null, 0);
			Card theCard4 = new Card(null, 0);
			theCard1.suite = "Heart";
			theCard1.value = i+1;
			deck.add(theCard1);
			theCard2.suite = "Spade";
			theCard2.value = i+1;
			deck.add(theCard2);
			theCard3.suite = "Club";
			theCard3.value = i+1;
			deck.add(theCard3);
			theCard4.suite = "Diamond";
			theCard4.value = i+1;
			deck.add(theCard4);
		}*/
		
		//for(int i = 0; i< deck.size(); i++) {
		//System.out.println(deck.get(i).suite + " " + deck.get(i).value);}
	}
	

	//Deal 2 cards and return them in the Array List
	public ArrayList<Card> dealHand(){
		if(deck.size() < 1) return null; //return null if all cards are dealt
		
		//get random number to get a random card in the deck
		Random random = new Random();
		int currentCard = random.nextInt(deck.size()-1);
		
		//create myHand to return;
		ArrayList<Card> myHand = new ArrayList<Card>();
		Card temp1 = deck.get(currentCard);			//First card
		myHand.add(temp1);
		deck.remove(temp1);
		Card temp2 = deck.get(currentCard);		//Second card
		myHand.add(temp2);
		deck.remove(temp2);
		return myHand;			
	}
	
	//Deal 1 card and return
	public Card drawOne() {
		if(deck.size() == 0) return null; //return null if all cards are dealt
		
		
		Random random = new Random();
		int currentCard = random.nextInt(deck.size());
		Card temp = deck.get(currentCard);	
		
		deck.remove(temp);
		return temp;	
	
	}
	
	//Shuffle and get the new deck
	public void shuffleDeck() {
		//Get the random number
		Random random = new Random();
		
		//shuffle the deck, random the second position of the card
		//and then use the second position card change the first
		//first position card.
		for (int first = 0; first < deck.size(); first++) {
			int second = random.nextInt(MAX_DECK_SIZE);
			Card temp = deck.get(first);
			deck.set(first, deck.get(second));
			deck.set(second, temp);
		}
	}
	
	//Return the size of card in the deck
	public int deckSize() {
		return deck.size();
	}
	
	
}