
import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class BaccaratGame extends Application {
	//Game Set
	BaccaratDealer game = new BaccaratDealer();
	BaccaratGameLogic gameLogic = new BaccaratGameLogic();	
	ArrayList<Card> p; 			//player's card list
	ArrayList<Card> b;			//banker's card list
	String whowon;				//store who won
	int p_total;				//player's total card points
	int b_total;				//banker's total card points
	double currentBet;			
	double totalWinnings;
	double balance = 1000;		//initial player's balance is $1000
	String betWho;				//get the side that the user
	
	
	//Layout Set
	BorderPane root;
	BorderPane innerRoot;
	NumberTextField bet_amount;
	Button btn_player;
	Button btn_draw;
	Button btn_banker;
	Button btn_start;
	TextArea textArea;
    HBox hbox;
	VBox vbox;
	Menu option;
	MenuBar menuBar;
	MenuItem one;
	MenuItem two;
	Image pic1;
	Label l_bet;
	Label l_balance;
	Label l_player;
	Label l_banker;
	Background b1;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);

		/*
		//create a game
		BaccaratDealer game = new BaccaratDealer();
		System.out.println(game.deck);
		//generate the deck
		game.generateDeck();
		System.out.println(game.deck.size());
		//shuffle the deck
		game.shuffleDeck();
		
		//Create two array to keep the deal hand of player/banker
		//ArrayList<Card> p = game.dealHand();
		//ArrayList<Card> b = game.dealHand();
		
		System.out.println(game.deckSize());
		
		BaccaratGameLogic gameLogic = new BaccaratGameLogic();
		Card playerCard = null;
		if(gameLogic.evaluatePlayerDraw(p) == true) {
			Card p_temp = game.drawOne();
			System.out.println("P_Draw: " + p_temp.suite + " " + p_temp.value);
			p.add(p_temp);
			playerCard = p_temp;
		}
		
		if(gameLogic.evaluateBankerDraw(b, playerCard) == true) {
			Card b_temp = game.drawOne();
			System.out.println("B_Draw: " + b_temp.suite + " " + b_temp.value);
			b.add(b_temp);
		}
		
		for(int i = 0; i < p.size(); i++) {
		System.out.println("Player:" + p.get(i).suite + " " + p.get(i).value);
		}
		System.out.println();
		
		for(int i = 0; i < b.size(); i++) {
		System.out.println("Banker:" + b.get(i).suite + " " + b.get(i).value);
		}
		System.out.println();
		
		
		System.out.println(gameLogic.whoWon(p, b));
		*/
		
		//TEST DRAW ONE
		/*for(int i = 0; i< 52;i++) {
			Card temp = game.drawOne();
			System.out.println(i+1 + ". " + temp.suite + " " + temp.value);
		}*/
		
		//TEST DEAL HAND
		/*for(int i = 0; i < 26; i++) {
			ArrayList<Card> temp = game.dealHand();
			System.out.println(i+1 + ". " + temp.get(0).suite + " " + temp.get(0).value
					+ "  |  " + temp.get(1).suite + " " + temp.get(1).value);
		}*/
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {

		//Layout Set
		primaryStage.setTitle("Let's Play Baccarat!!!");
		root = new BorderPane();
		innerRoot = new BorderPane();
		bet_amount = new NumberTextField();
		btn_player = new Button("Player");
		btn_draw = new Button("Draw");
		btn_banker = new Button("Banker");
	    btn_start = new Button("START");
		textArea = new TextArea(
				"***      Welcome to play Baccarat at PEIQI's HOUSE!        ***\n" +
				"*** Type the bet amount and click the buttoms to start! ***");
		option = new Menu("Option");
		menuBar = new MenuBar();
		one = new MenuItem("Refresh Start");
		two = new MenuItem("Exit");
		pic1 = new Image("583060111.jpg");
		l_bet = new Label("Bet: $");
		l_balance = new Label("Balance:\n" + "$ " + balance);
		l_player = new Label("PLAYER");
		l_banker = new Label("BANKER");
		textArea.setMaxHeight(100);

		
		//Set bet amount 0 as initial;
		bet_amount.setText("0");
		
		//Set Background Size
		BackgroundSize size = new BackgroundSize(988,
				583, false, false, true, false);
		
		//Set Background
		Background b1 = new Background(new BackgroundImage(pic1, 
				BackgroundRepeat.NO_REPEAT, 
				BackgroundRepeat.NO_REPEAT, 
				BackgroundPosition.CENTER, size));
	    innerRoot.setBackground(b1);

	    //label bet
	    l_bet.setTextFill(Color.ALICEBLUE);
	    l_bet.setStyle("-fx-font-size: 20;");

	    //label player
	    l_player.setTextFill(Color.YELLOW);
	    l_player.setStyle("-fx-font-size: 24;");
	    l_player.setTranslateX(255);
	    l_player.setTranslateY(140);
	    l_player.setUnderline(true);
	    
	    //label banker
	    l_banker.setTextFill(Color.YELLOW);
	    l_banker.setStyle("-fx-font-size: 24;");
	    l_banker.setUnderline(true);
	    l_banker.setTranslateY(140);
	    l_banker.setTranslateX(-230);
	  
	    //Set label player and banker to the correct position
	    innerRoot.setLeft(l_player);
	    innerRoot.setRight(l_banker);
	    
	    //H-Box in Button
	    hbox = new HBox(20, l_bet, bet_amount, btn_player, btn_draw, btn_banker);
	    hbox.setAlignment(Pos.CENTER);
	    hbox.setStyle("-fx-background-color: #0c1262;");
	    
		
		//H-Box 2 (Start)
	    HBox hbox2 = new HBox(850, btn_start, l_balance);
	    
	    //V-Box 1 (Menu bar)
		vbox = new VBox(5, menuBar, hbox2);
		//vbox.setAlignment(Pos.CENTER);
		
		//V-Box 2 (bet section)
		VBox vbox2 = new VBox(5, hbox, textArea);
		
		//Menu Set
		option.getItems().addAll(one, two);
	    menuBar.getMenus().add(option);
		
	    btn_start.setDisable(true);
   
		//Action 
		one.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				//Reset all buttons be enabled
				btn_player.setDisable(false);
				btn_draw.setDisable(false);
				btn_banker.setDisable(false);
				btn_start.setDisable(false);
				
				//Reset bet amount
				bet_amount.setText("0");
				
				//Reset inner root
				innerRoot.getChildren().clear();
			    innerRoot.setLeft(l_player);
			    innerRoot.setRight(l_banker);
				textArea.setText("The Game is now refreshed.\n" +
						"Now, you can bet and play a new game.\n" +
						"Goode Luck!");
			}
		});

		//Action of Exit;
		two.setOnAction(e-> primaryStage.close());
	
		//Action of Player Button
		btn_player.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent event) {
		    	btn_start.setDisable(false);
				//Get amount from the text
				String t1 = bet_amount.getText();
				currentBet = Double.parseDouble(t1);
				
				//Game only can start when user bet more than 0 dollars
				if(currentBet > 0) {
					//if user bet more than balance, say sorry
					if(currentBet > balance){
						textArea.setText("***Sorry You don't have enough balance***\n" +
										 "***Please refresh the game to continue***");
						btn_start.setDisable(true);
					}
					else {
						//get that the user bet player
						betWho = "Player";
						textArea.setText("You bet $" + currentBet + " on the Player.\n"
							+ "Please click the START button.");
					}
					//after bet, disable all buttons
					btn_player.setDisable(true);
					btn_draw.setDisable(true);
					btn_banker.setDisable(true);
					
			}
				else {
					textArea.setText("Bet amount should more than $0");
				}
			}
		});
		
		//Action of Draw Button
		btn_draw.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent event) {
		    	btn_start.setDisable(false);
				//Get amount from the text
				String t1 = bet_amount.getText();
				currentBet = Double.parseDouble(t1);
				
				//Game only can start when user bet more than 0 dollars
				if(currentBet > 0) {
					//if user bet more than balance, say sorry
					if(currentBet > balance){
						textArea.setText("***Sorry You don't have enough balance***\n" +
										 "***Please refresh the game to continue***");
						btn_start.setDisable(true);
					}
					else {
						//get that the user bet draw
						betWho = "Draw";
						textArea.setText("You bet $" + currentBet + " on the Draw.\n"
							+ "Please click the START button.");
					}
					//after bet, disable all buttons
					btn_player.setDisable(true);
					btn_draw.setDisable(true);
					btn_banker.setDisable(true);
				}
				else {
					textArea.setText("Bet amount should more than $0");
				}
			}
		});
		
		//Action of Banker Button
		btn_banker.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent event) {
		    	btn_start.setDisable(false);
				//Get amount from the text
				String t1 = bet_amount.getText();
				currentBet = Double.parseDouble(t1);
				
				//Game only can start when user bet more than 0 dollars
				if(currentBet > 0) {
					//if user bet more than balance, say sorry
					if(currentBet > balance){
						textArea.setText("***Sorry You don't have enough balance***\n" +
										 "***Please refresh the game to continue***");
						btn_start.setDisable(true);
					}
					else {
						//get that the user bet banker
						betWho = "Banker";
						textArea.setText("You bet $" + currentBet + " on the Banker.\n"
							+ "Please click the START button.");
					}
					//after bet, disable all buttons
					btn_player.setDisable(true);
					btn_draw.setDisable(true);
					btn_banker.setDisable(true);
				}
				else {
					textArea.setText("Bet amount should more than $0");
				}
			}
		});
		
		//Action of Start Button
		btn_start.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				//Get amount from the text
				String t1 = bet_amount.getText();
				currentBet = Double.parseDouble(t1);
				
				//Game only can start when user bet more than 0 dollars
				if(currentBet > 0) {
					
					//generate the deck
					game.generateDeck();
					
					//shuffle the deck
					game.shuffleDeck();
					
					//Create two array to keep the deal hand of player/banker
					p = game.dealHand();
					b = game.dealHand();
					
					//Test
					/*textArea.setText(
							"Player: " + p.get(0).suite + " " + p.get(0).value +
							" AND " +p.get(1).suite + " " + p.get(1).value +
							"\n" + "Banker: " + b.get(0).suite + " " + b.get(0).value +
							" AND " +b.get(1).suite + " " + b.get(1).value			
							);*/
					
					//If start the game, the button should be disable
					btn_start.setDisable(true);
					
					//calculate the card value of player, and use this value to access the card picture
					int p1_value = countCardNumber(p.get(0).suite, p.get(0).value);
					int p2_value = countCardNumber(p.get(1).suite, p.get(1).value);
					ImageView p_view1 = new ImageView(new Image(p1_value +".png"));
					ImageView p_view2 = new ImageView(new Image(p2_value +".png"));
					
					//set players card attribution
					p_view1.setX(240);
					p_view1.setY(180);
					p_view1.setFitWidth(100);
					p_view1.setFitHeight(124);
					p_view2.setX(265);
					p_view2.setY(180);
					p_view2.setFitWidth(100);
					p_view2.setFitHeight(124);
					p_view2.setPreserveRatio(true);
					
					//calculate the card value of banker, and use this value to access the card picture
					int b1_value = countCardNumber(b.get(0).suite, b.get(0).value);
					int b2_value = countCardNumber(b.get(1).suite, b.get(1).value);
					ImageView b_view1 = new ImageView(new Image(b1_value +".png"));
					ImageView b_view2 = new ImageView(new Image(b2_value +".png"));
					
					//set bankers card attribution
					b_view1.setX(665);
					b_view1.setY(180);
					b_view1.setFitWidth(100);
					b_view1.setFitHeight(124);
					b_view2.setX(690);
					b_view2.setY(180);
					b_view2.setFitWidth(100);
					b_view2.setFitHeight(124);
					
					//show the card in the inner border pan
					innerRoot.getChildren().addAll(p_view1, p_view2, b_view1, b_view2);
					
					//initial the card player receive as null
					Card playerCard = null;
					
					//determine whether play draw a new card
					if(gameLogic.evaluatePlayerDraw(p) == true) {
						Card p_temp = game.drawOne();
						p.add(p_temp);
						playerCard = p_temp;
						int p3_value = countCardNumber(p.get(2).suite, p.get(2).value);
						ImageView p_view3 = new ImageView(new Image(p3_value +".png"));
						p_view3.setX(370);
						p_view3.setY(180);
						p_view3.setFitWidth(100);
						p_view3.setFitHeight(124);
						innerRoot.getChildren().add(p_view3);
					}
					
					//determine whether banker draw a new card
					if(gameLogic.evaluateBankerDraw(b, playerCard) == true) {
						Card b_temp = game.drawOne();
						b.add(b_temp);
						playerCard = b_temp;
						int b3_value = countCardNumber(b.get(2).suite, b.get(2).value);
						ImageView b_view3 = new ImageView(new Image(b3_value +".png"));
						b_view3.setX(795);
						b_view3.setY(180);
						b_view3.setFitWidth(100);
						b_view3.setFitHeight(124);
						innerRoot.getChildren().add(b_view3);
					}
					
					//get who won
					whowon = gameLogic.whoWon(p, b);
					
					//get the player's and card's card total number
					p_total = gameLogic.handTotal(p);
					b_total = gameLogic.handTotal(b);
					double temp = evaluateWinnings();
					balance = balance + temp;
					if(whowon == betWho) {
						textArea.setText("Player Total: " + p_total + " Banker Total: " + b_total + "\n" +
										 whowon + " wins\n" +
										 "Congrats, you bet " + betWho + "! You win!" + "\n\n" +
										 "Your balance: " + balance);
					}
					else {		
						textArea.setText("Player Total: " + p_total + " Banker Total: " + b_total + "\n" +
								 whowon + " wins\n" +
								 "Sorry, you bet " + betWho + "! You lost your bet!" + "\n\n" +
								 "Your balance: " + balance);
					}
					
					l_balance.setText("Balance:\n" + "$ " + balance);
					
				}
				else {
					textArea.setText("Please place a bet first!");
				}
				
			}
		});
		
		//BoardPane
		root.setBottom(vbox2);
	    root.setTop(vbox);
	    root.setCenter(innerRoot);
	   
	    //Scene
		Scene scene = new Scene(root,992,646);
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.show();
		
	}
	
	//NumberTextField for bet amount to avoid players type other type
	public class NumberTextField extends TextField
	{

	    public void replaceText(int start, int end, String text)
	    {
	        if (validate(text))
	        {
	            super.replaceText(start, end, text);
	        }
	    }

	    public void replaceSelection(String text)
	    {
	        if (validate(text))
	        {
	            super.replaceSelection(text);
	        }
	    }

	    private boolean validate(String text)
	    {
	        return text.matches("[0,1,2,3,4,5,6,7,8,9,.]*");
	    }
	}

	//Help to count the card Number and use it to get the picture from the resource
	public Integer countCardNumber(String suite, int faceValue) {
		int result = 0;
		if(suite == "Heart") {
			result = faceValue;
		}
		else if(suite == "Spade") {
			result = 13 + faceValue;
		}
		else if(suite == "Club") {
			result = 26 + faceValue;
		}
		else if(suite == "Diamond") {
			result = 39 + faceValue;
		}
		return result;
	}
	
	//Determine if the user won or lost and return amount of totalWinnings
	public double evaluateWinnings() {
		//if win
		if(whowon == betWho) {
			if(betWho == "Player") {
				totalWinnings = currentBet;
			}
			if(betWho == "Banker") {
				totalWinnings = currentBet * 0.95;
			}
			if(betWho == "Draw") {
				totalWinnings = currentBet * 8;
			}
		}
		//if lose
		else {
			totalWinnings = -currentBet;
		}

		return totalWinnings;
	}
}
