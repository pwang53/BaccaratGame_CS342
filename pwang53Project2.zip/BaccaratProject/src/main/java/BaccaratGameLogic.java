import java.util.ArrayList;

class BaccaratGameLogic {
	//Return people win the game after evaluate two hands
	public String whoWon(ArrayList<Card> hand1, ArrayList<Card> hand2) {
		//get the final points of player and banker (According to the rule)
		int p_points = handTotal(hand1);
		int b_points = handTotal(hand2);

		//Compare player's points with banker's points
		if(p_points > b_points) {
			return "Player";
		}
		else if(p_points < b_points){
			return "Banker";
		}
		else {
			return "Draw";
		}
	}
	
	//Return points that the hand is worth
	public int handTotal(ArrayList<Card> hand) {
		//initial total points
		int points = 0;

		//add all card points up
		for(int i = 0; i < hand.size(); i++) {
			int temp = hand.get(i).value;
			if(temp <= 10) {
				points = points + temp;
			}
		}
		
		//return the total points
		return points % 10;
	}
	
	//Return true if banker needs a third card
	public boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard) {
		//store the player card value
		int value;
		
		//if player card exist, then store the points, else set as -1 to represent card is null
		if(playerCard != null) {
			value = playerCard.value % 10;
		}
		else {
			value = -1;
		}

		//hand totals 7 or more, no draw
		//if(handTotal(hand) > 6) return false;
		
		//#hand totals 2 or less, draw 
		if(handTotal(hand) < 3) return true;
		
		//#hand totals is 3 and the playerCard is 0,1,2,3,4,5,6,7,9 or null, draw
		if(handTotal(hand) == 3 && value != 8) return true; 
		
		//hand totals is 4 and the playerCard is 2,3,4,5,6,7 or null, draw
		if(handTotal(hand) == 4 && (value != 0 || value != 1 || value != 8 || value != 9)) return true;
		
		//#hand totals is 5 and the playerCard is 4,5,6,7 or null, draw
		if(handTotal(hand) == 5 && (value == 4 || value == 5 || value == 6 || value == 7 || value == -1)) return true;
		
		//#hand totals is 6 and the playerCard is 6 or 7, draw
		if(handTotal(hand) == 6 && (value == 6 || value == 7)) return true; 
		
		//#
		return false;
	}
	
	//Return true if player needs a third card
	public boolean evaluatePlayerDraw(ArrayList<Card> hand) {
		//hand totals to 5 or less, draw
		if(handTotal(hand) < 6) {
			return true;
		}
		
		return false;
	}
	
}