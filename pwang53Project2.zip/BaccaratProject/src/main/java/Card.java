class Card{
	//set the suite and value of a card
	String suite;
	int value;
	
	//Constructor of the card
	Card(String theSuite, int theValue){
		this.suite = theSuite;
		this.value = theValue;
	}
}